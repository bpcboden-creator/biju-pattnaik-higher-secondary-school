BIJU PATTNAIK HIGHER SECONDARY SCHOOL, BODEN — BILINGUAL WEBSITE

Included:
- index.html: Responsive one-page website with English/Odia language switcher.
- README.txt: Publishing and editing instructions.

HOW TO PREVIEW
1. Extract this ZIP.
2. Double-click index.html to open it in Chrome, Edge, Firefox, or another browser.
3. Click the language button in the navigation bar to switch between English and Odia.

HOW TO EDIT
1. Open index.html in a plain-text editor such as Notepad or Visual Studio Code.
2. Search for the placeholder text you want to change and edit it carefully.
3. For bilingual text, update both data-en="English text" and data-or="Odia text" values. Keep quotation marks and the HTML structure intact.
4. Replace the sample notice text with current, approved notices.
5. Add official phone/email only after verifying them.
6. To add a photo, put the image file beside index.html and replace a gallery placeholder with an image tag, e.g. <img src="campus.jpg" alt="School campus">. Add suitable CSS to size it.
7. Save the file and refresh your browser preview.

FREE PUBLISHING WITH NETLIFY DROP
1. Extract the ZIP file.
2. Open https://app.netlify.com/drop in your browser.
3. Sign in or create a free Netlify account if prompted.
4. Drag the folder containing index.html onto the drop area (or follow the page's upload instructions).
5. Wait for deployment and open the generated site URL.
6. Keep a backup of the ZIP and use Netlify's site dashboard to manage future updates. To update, upload the revised site files through the dashboard's supported deploy workflow.

ALTERNATIVE: GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a new public repository.
3. Upload index.html to the repository root.
4. Open Settings > Pages and select deployment from the main branch/root.
5. Save and wait for the published URL to appear.

IMPORTANT
- The site is a starter template, not yet published online.
- The address is currently shown as Boden, Odisha, India.
- Phone and email are intentionally placeholders until official details are verified.
- Confirm school name spelling, Odia wording, streams, affiliation details, notices, and all claims with the school before publishing.
- Do not publish sensitive student data. Obtain appropriate consent for identifiable student photos.
